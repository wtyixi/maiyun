package com.bage.common.netty;

public class NettyServerCacheConstant {
    public static final String CLIENT_ID = "CLIENT_ID:";
}
