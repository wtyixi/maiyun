package com.bage.finance.biz.constant;


public class CMDConstant {
    /**
     * 扫码登录
     */
    public static final String SCAN_LOGIN = "SCAN_LOGIN";
}
