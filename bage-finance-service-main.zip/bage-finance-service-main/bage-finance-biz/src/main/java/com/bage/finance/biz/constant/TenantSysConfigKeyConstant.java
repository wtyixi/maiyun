package com.bage.finance.biz.constant;

public class TenantSysConfigKeyConstant {
    /**
     * 科目编码长度配置
     */
    public static final String SUBJECT_CODE_LENGTH_CONFIG = "subject_code_length_config";
}
