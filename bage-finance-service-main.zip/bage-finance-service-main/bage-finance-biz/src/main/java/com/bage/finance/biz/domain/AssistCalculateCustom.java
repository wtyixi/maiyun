package com.bage.finance.biz.domain;

import java.util.Date;

/**
 * 辅助核算（表：assist_calculate_custom）
 *
 * @author bage
 */
public class AssistCalculateCustom {
    /**
     * 
     */
    private Long id;

    /**
     * 自定义字段1
     */
    private String c1;

    /**
     * 自定义字段2
     */
    private String c2;

    /**
     * 自定义字段3
     */
    private String c3;

    /**
     * 自定义字段4
     */
    private String c4;

    /**
     * 自定义字段5
     */
    private String c5;

    /**
     * 自定义字段6
     */
    private String c6;

    /**
     * 自定义字段7
     */
    private String c7;

    /**
     * 自定义字段8
     */
    private String c8;

    /**
     * 自定义字段9
     */
    private String c9;

    /**
     * 是否禁用
     */
    private Boolean disable;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 用户id
     */
    private Long memberId;

    /**
     * 修改用户id
     */
    private Long updateMemberId;

    /**
     * 是否删除，0：删除，1：未删除
     */
    private Boolean delFlag;

    /**
     * 租户id
     */
    private Long tenantId;

    /**
     * 自定义字段10
     */
    private String c10;

    /**
     * 辅助核算id
     */
    private Long assistCalculateSummaryId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getC1() {
        return c1;
    }

    public void setC1(String c1) {
        this.c1 = c1;
    }

    public String getC2() {
        return c2;
    }

    public void setC2(String c2) {
        this.c2 = c2;
    }

    public String getC3() {
        return c3;
    }

    public void setC3(String c3) {
        this.c3 = c3;
    }

    public String getC4() {
        return c4;
    }

    public void setC4(String c4) {
        this.c4 = c4;
    }

    public String getC5() {
        return c5;
    }

    public void setC5(String c5) {
        this.c5 = c5;
    }

    public String getC6() {
        return c6;
    }

    public void setC6(String c6) {
        this.c6 = c6;
    }

    public String getC7() {
        return c7;
    }

    public void setC7(String c7) {
        this.c7 = c7;
    }

    public String getC8() {
        return c8;
    }

    public void setC8(String c8) {
        this.c8 = c8;
    }

    public String getC9() {
        return c9;
    }

    public void setC9(String c9) {
        this.c9 = c9;
    }

    public Boolean getDisable() {
        return disable;
    }

    public void setDisable(Boolean disable) {
        this.disable = disable;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Long getUpdateMemberId() {
        return updateMemberId;
    }

    public void setUpdateMemberId(Long updateMemberId) {
        this.updateMemberId = updateMemberId;
    }

    public Boolean getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Boolean delFlag) {
        this.delFlag = delFlag;
    }

    public Long getTenantId() {
        return tenantId;
    }

    public void setTenantId(Long tenantId) {
        this.tenantId = tenantId;
    }

    public String getC10() {
        return c10;
    }

    public void setC10(String c10) {
        this.c10 = c10;
    }

    public Long getAssistCalculateSummaryId() {
        return assistCalculateSummaryId;
    }

    public void setAssistCalculateSummaryId(Long assistCalculateSummaryId) {
        this.assistCalculateSummaryId = assistCalculateSummaryId;
    }

    public void initDefault() {
        if (this.getC1() == null) {
            this.setC1("");
        }
        if (this.getC2() == null) {
            this.setC2("");
        }
        if (this.getC3() == null) {
            this.setC3("");
        }
        if (this.getC4() == null) {
            this.setC4("");
        }
        if (this.getC5() == null) {
            this.setC5("");
        }
        if (this.getC6() == null) {
            this.setC6("");
        }
        if (this.getC7() == null) {
            this.setC7("");
        }
        if (this.getC8() == null) {
            this.setC8("");
        }
        if (this.getC9() == null) {
            this.setC9("");
        }
        if (this.getDisable() == null) {
            this.setDisable(false);
        }
        if (this.getCreateTime() == null) {
            this.setCreateTime(new Date());
        }
        if (this.getUpdateTime() == null) {
            this.setUpdateTime(new Date());
        }
        if (this.getMemberId() == null) {
            this.setMemberId(0L);
        }
        if (this.getUpdateMemberId() == null) {
            this.setUpdateMemberId(0L);
        }
        if (this.getDelFlag() == null) {
            this.setDelFlag(false);
        }
        if (this.getTenantId() == null) {
            this.setTenantId(0L);
        }
        if (this.getC10() == null) {
            this.setC10("");
        }
        if (this.getAssistCalculateSummaryId() == null) {
            this.setAssistCalculateSummaryId(0L);
        }
    }

    public void initUpdate() {
    }
}