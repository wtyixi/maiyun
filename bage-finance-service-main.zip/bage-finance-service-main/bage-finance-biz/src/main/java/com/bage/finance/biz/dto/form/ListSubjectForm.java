package com.bage.finance.biz.dto.form;

import lombok.Data;

/**
 * 查询科目
 */
@Data
public class ListSubjectForm {
    /**
     * 科目类别
     */
    private Integer subjectCate;
}