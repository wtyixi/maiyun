package com.bage.finance.biz.dto.vo;


import lombok.Data;

@Data
public class DataDictionaryVo {
    /**
     * 数据编码
     */
    private String dataCode;

    /**
     * 数据值
     */
    private String dataValue;
}
