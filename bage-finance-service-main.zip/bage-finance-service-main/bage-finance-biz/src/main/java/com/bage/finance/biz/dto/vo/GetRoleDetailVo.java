package com.bage.finance.biz.dto.vo;


import lombok.Data;

@Data
public class GetRoleDetailVo {
    /**
     *角色id
     */
    private Integer id;
    /**
     *角色名称
     */
    private String roleName;
}
