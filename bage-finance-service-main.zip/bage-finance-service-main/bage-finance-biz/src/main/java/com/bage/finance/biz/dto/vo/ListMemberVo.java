package com.bage.finance.biz.dto.vo;


import lombok.Data;

@Data
public class ListMemberVo {
    /**
     *用户id
     */
    private Long id;

    /**
     *昵称
     */
    private String nickName;
}
