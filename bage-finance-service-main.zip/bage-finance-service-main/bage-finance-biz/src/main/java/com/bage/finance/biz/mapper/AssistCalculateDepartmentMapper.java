package com.bage.finance.biz.mapper;

import com.bage.finance.biz.domain.AssistCalculateDepartment;
import com.bage.mybatis.help.CommonMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AssistCalculateDepartmentMapper extends CommonMapper<AssistCalculateDepartment> {
}