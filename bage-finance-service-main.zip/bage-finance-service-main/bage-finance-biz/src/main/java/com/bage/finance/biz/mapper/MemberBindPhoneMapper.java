package com.bage.finance.biz.mapper;

import com.bage.finance.biz.domain.MemberBindPhone;
import com.bage.mybatis.help.CommonMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberBindPhoneMapper extends CommonMapper<MemberBindPhone> {
}