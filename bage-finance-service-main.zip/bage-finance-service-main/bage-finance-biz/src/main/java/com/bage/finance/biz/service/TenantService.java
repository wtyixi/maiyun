package com.bage.finance.biz.service;

public interface TenantService {
    /**
     * 创建租户
     *
     * @return
     */
    long add();
}
