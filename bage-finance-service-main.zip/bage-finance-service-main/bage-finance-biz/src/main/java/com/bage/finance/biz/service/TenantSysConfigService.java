package com.bage.finance.biz.service;


import com.bage.finance.biz.dto.vo.SubjectCodeLengthConfigVo;

public interface TenantSysConfigService {
    SubjectCodeLengthConfigVo getSubjectCodeLengthConfig();
}
