package com.bage.finance.biz.service.impl;

import com.bage.finance.biz.service.SysRegionService;
import org.springframework.stereotype.Service;

@Service
public class SysRegionServiceImpl implements SysRegionService {
    /**
     * 获取区县信息
     *
     * @param provinceCode
     * @param cityCode
     * @param countyCode
     * @return
     */
    @Override
    public void checkRegionCode(String provinceCode, String cityCode, String countyCode) {

    }
}
